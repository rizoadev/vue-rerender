<template lang="pug">
Tasks
</template>

<script>
// @ is an alias to /src
import Tasks from "@/components/Tasks";

export default {
  name: "Home",
  components: {
    Tasks,
  },
};
</script>
